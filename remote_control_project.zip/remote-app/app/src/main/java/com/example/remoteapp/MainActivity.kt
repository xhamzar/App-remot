package com.example.remoteapp

class MainActivity {}
