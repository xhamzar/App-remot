Android Remote Control Project Placeholder.
Replace with full source from canvas.